#pragma once

// functions we use in testing-examples.cpp

int factorial(int number); // definition before use
